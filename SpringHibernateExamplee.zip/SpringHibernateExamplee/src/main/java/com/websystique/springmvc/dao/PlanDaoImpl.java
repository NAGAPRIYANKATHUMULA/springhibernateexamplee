package com.websystique.springmvc.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.springframework.stereotype.Repository;

import com.websystique.springmvc.model.Plan;
@Repository("PlanDao")
public class PlanDaoImpl extends AbstractDao implements PlanDao {

	 @SuppressWarnings("unchecked")
	    public List<Plan> findAllPlans() {
	        Criteria criteria = createEntityCriteria();
	        return (List<Plan>) criteria.list();
	    }
	 

}
