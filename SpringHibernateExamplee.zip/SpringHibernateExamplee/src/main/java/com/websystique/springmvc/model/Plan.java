package com.websystique.springmvc.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


 
@Entity
@Table(name="plan")
public class Plan {

	@Id
	private String Planname;
	private int Premium;
	public String getPlanname() {
		return Planname;
	}
	public void setPlanname(String planname) {
		Planname = planname;
	}
	public int getPremium() {
		return Premium;
	}
	public void setPremium(int premium) {
		Premium = premium;
	}
	
	
}
