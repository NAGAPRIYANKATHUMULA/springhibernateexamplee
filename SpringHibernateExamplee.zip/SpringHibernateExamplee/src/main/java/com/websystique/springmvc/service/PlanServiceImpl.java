package com.websystique.springmvc.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.websystique.springmvc.dao.PlanDao;
import com.websystique.springmvc.model.Plan;

@Service("PlanService")
@Transactional
public class PlanServiceImpl implements PlanService {
	
	 @Autowired
	    private PlanDao dao;

	public List<Plan> findAllplans() {
		// TODO Auto-generated method stub
		return dao.findAllPlans();
	}

}
